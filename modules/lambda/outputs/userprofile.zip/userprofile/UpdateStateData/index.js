'use strict'

const db = require('./dbConfig');

exports.handler = function(event, context, callback) {
    const userInfo = JSON.parse(event.Records[0].Sns.Message);
	
    let stmt = `UPDATE userprofile SET state = ${userInfo.userregistrationstate} WHERE cognito_username = ${userInfo.cognito_username}`;
    db.query(stmt, (err, results, fields) => {
        if (err) {
            console.log(err);
            var error = new Error("Due to error unable to update data");
            callback(error);
        }
        context.succeed('Data successfully Updated');
    });
}