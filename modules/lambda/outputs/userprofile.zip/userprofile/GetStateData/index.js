'use strict'

const db = require('./dbConfig');

exports.handler = function(event, context, callback) {

	const userInfo = JSON.parse(event.Records[0].Sns.Message);

	db.query('SELECT * from userprofile where cognito_username = $1', [userInfo.cognito_username], function (err, result) {
		if (err) {
			console.log(err);
			var error = new Error("Error retrieving data with id=" + userInfo.cognito_username);
			callback(error);
		}
		context.succeed(result.rows);
	});
}