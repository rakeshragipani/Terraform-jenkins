const db = require('./dbConfig');

exports.handler = function(event, context, callback) {
	const uuid = require('uuid');

    const userInfo = JSON.parse(event.Records[0].Sns.Message);
    const jsonData = {
        "first_name": userInfo.firstname,
        "last_name": userInfo.lastname,
        "age": userInfo.age,
        "date_of_birth": userInfo.dateofbirth,
        "tenant_id": userInfo.tenant_id,
        "retirement_age": userInfo.retirementAge,
        "email": userInfo.email,
        "cognito_username": userInfo.cognito_username,
        "state": userInfo.userregistrationstate,
        "uuid": uuid.v4()
    };
	
	console.log("event data: ", userInfo.cognito_username);
    let stmt = `INSERT INTO userprofile(uuid,first_name,last_name,age,date_of_birth,tenant_id,retirement_age,email,cognito_username,state) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)  `;
    db.query(stmt, [jsonData.uuid,jsonData.first_name,jsonData.last_name,jsonData.age,jsonData.date_of_birth,jsonData.tenant_id,jsonData.retirement_age,jsonData.email,jsonData.cognito_username,jsonData.state], (err, results, fields) => {
        if (err) {
            console.log(err);
            var error = new Error("Due to error unable to insert data");
            callback(error);
        }
        context.succeed('Data successfully Inserted');
    });
};
