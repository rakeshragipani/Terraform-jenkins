def hello(event, context):
    print("welcome to terraform")
